# Welzo Market

Nova versão do site estático do Welzo Market.

## Arquivos
- `index.html` - página principal
- `style.css` - visual e responsividade
- `app.js` - interações
- `Guia_Como_Criar_uma_Renda_Digital.pdf` - produto digital

## Importante
O site é apenas uma vitrine nesta versão. O botão de compra não processa pagamentos reais.
Não coloque PIN, palavra-passe ou códigos SMS no repositório.

O pagamento oficial e a entrega automática serão configurados numa etapa posterior.
