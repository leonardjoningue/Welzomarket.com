const modal = document.getElementById("modal");
const buyButton = document.getElementById("buyButton");
const closeModal = document.getElementById("closeModal");
const okModal = document.getElementById("okModal");

function openModal() {
  modal.classList.add("show");
  modal.setAttribute("aria-hidden", "false");
}
function close() {
  modal.classList.remove("show");
  modal.setAttribute("aria-hidden", "true");
}
buyButton.addEventListener("click", openModal);
closeModal.addEventListener("click", close);
okModal.addEventListener("click", close);
modal.addEventListener("click", (event) => {
  if (event.target === modal) close();
});
document.getElementById("year").textContent = new Date().getFullYear();
